# Frontend

The frontend of [codergogoi/nodejs_microservice](https://github.com/codergogoi/nodejs_microservice) had some issues of depracated packages. This repo fixes them.