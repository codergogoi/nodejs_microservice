import {
  Route,
  BrowserRouter as Router,
  Routes
} from 'react-router-dom';
import './App.css';
import { Header } from './components';
import { Home, Login } from './pages';
import { ProductDetails } from './pages/ProductDetail';

function App() {
  return <Router>
            <div>
              <Header />
              <Routes>
                <Route path="/details/:id" element={<ProductDetails/>} />
                <Route path="/login" element={<Login/>} />
                <Route path="/" element={<Home/>} />
              </Routes>
            </div>
        </Router>
   
}

export default App;