# nodejs_microservice_rpc_communication
We all know how to call api and get some response with the help of HTTP calls in NodeJS but when it comes to distributed DB we need to think about a machanism to fullfil the requirement.

In this repository we have implemented Message Broker RPC call to communicate with other microservice to get on demand data from distributed DB.

Let's check it out and if it is useful to you leave a star for me :)


Thank you

## Tutorial Link:
[NodeJS Microservices RPC Communication](https://youtu.be/qn3EM_U_4-g)
