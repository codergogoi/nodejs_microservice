// which service it is
describe("ProductService", () => {
  // Which function
  describe("CreateProduct", () => {
    // Which Scenario we are testing
    test("validate user inputs", () => {});

    test("Validate response", async () => {});
  });
});
