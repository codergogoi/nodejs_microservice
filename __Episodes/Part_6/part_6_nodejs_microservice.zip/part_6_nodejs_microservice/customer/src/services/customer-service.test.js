// which service it is
describe("CustomerService", () => {
  // This will explain which function we are testing!
  describe("SignIn", () => {
    // Which Scenario we are testing
    test("validate user inputs", () => {});

    test("Validate response", async () => {});
  });
});
